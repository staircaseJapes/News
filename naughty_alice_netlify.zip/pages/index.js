export default function Home() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>The Naughty Times (Static Version)</h1>
      <p>Alice Tusa accused of global pillow theft, cookie raids, and excessive napping at G7 summits.</p>
      <p>This site was exported statically for Netlify. Full features available in the dynamic version.</p>
    </div>
  );
}
