module.exports = {
  output: 'export',
  reactStrictMode: true
};